# Ad-hoc review-helper verification

This is focused **ad-hoc verification**, not a KanbanFlow suite pass or testing of PR511/PR521.

Temporary verifier: `<user-profile>/AppData/Local/Temp/hermes-verify-rmse74db.py`, allocated with `tempfile.mkstemp(prefix='hermes-verify-')`.

Initial run failed full-body preservation: Windows text writes expanded source CRLF into extra blank lines. Raw JSON remained intact. Corrected `collect_review.py` and `format_threads.py` Markdown writes with `newline=''`; regenerated only derived files from archived inputs. No remote calls or repository changes were needed.

Final command: `python <user-profile>/AppData/Local/Temp/hermes-verify-rmse74db.py`
Exit code: **0**.

Actual output:
```
PASS: all five helper scripts compile without executing remote operations
PASS: batching preserves all 182 full issue bodies
PASS: all 182 dispositions are unique and complete; missing-item negative control rejected
PASS: exact split-diff round trip and paginated metadata match (121 + 3 files); thread pages complete
PASS: actual formatter replay preserves full bodies/comments/reviews for all 12 records; scratch data removed
PASS: actual attachment assembly produces complete batches {'inventory': 8, 'pr': 4, 'threads': 11}
AD-HOC VERIFICATION PASSED; no KanbanFlow test suite or PR execution performed
```

Body comparisons permit normal CRLF-to-LF reading, not added blank lines. Formatter behavior was executed against archived real responses in an isolated temporary directory. Attachment assembly was executed without launching agents. Metadata and diff integrity were checked against previously fetched real GitHub records. This does not re-exercise network failures, pagination against a changing server, or subprocess timeouts. Those remain limits of the helper check.
